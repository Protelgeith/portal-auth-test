## Welcome to the portal de proveedores stack

The portal de proveedores stack is intended to provide a simple and fun starting point for cloud native fullstack javascript applications.

### Installation 
``` 
cp .env-example .env
yarn install
yarn build
yarn start (for development)
yarn serve (for production)
```

# AngularMaterial

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.7.4.
