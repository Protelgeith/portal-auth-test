export enum HttpErrTypes {
    unauthorized,
    duplicate_user,
    duplicate_preregister,
    active_register,
    inactive_user,
    change_pass_jwt_expired,
    change_pass_invalid_token
}
