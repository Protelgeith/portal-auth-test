import { RemovedorComillasPipe } from './removedor-comillas.pipe';

describe('RemovedorComillasPipe', () => {
  it('create an instance', () => {
    const pipe = new RemovedorComillasPipe();
    expect(pipe).toBeTruthy();
  });
});
