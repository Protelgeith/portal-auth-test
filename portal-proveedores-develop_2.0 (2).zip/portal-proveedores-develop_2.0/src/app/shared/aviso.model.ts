export class Aviso {
	constructor (
		title: string,
		description: string,
		start: string,
		end: string,
		institution: string[]
	) {}
}